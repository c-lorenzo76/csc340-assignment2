/**
 * @author cristianlorenzo
 *  Date: February 3, 2022
 *  Assignment: API Prototype
 * 
 *  Create a simple prototype application that connects to a third party API of your choice, 
 *  returns information, parses the most relevant piece of that information, and prints it to 
 *  the system output. 
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
			
			
			String url = "https://v2.jokeapi.dev/joke/Any?safe-mode";
			
			URL u = new URL(url);
			HttpURLConnection con = (HttpURLConnection) u.openConnection();
			
			
			if(con.getResponseCode()==200) {
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String line;
				
				StringBuffer response = new StringBuffer();
	
				while((line = in.readLine()) !=null) {
					response.append(line);
				}
				in.close();
				
				/**
				 * 	add json jar from 'external jar' in project folder to the build path
				 *  del the prev and add 
				 */
				JSONObject info = new JSONObject(response.toString());
				
				System.out.println("Category: " + info.get("category"));
				System.out.println("Type: " + info.get("type"));
				
				if(info.has("setup")) {
					System.out.println("Setup: " + info.get("setup"));
					Thread.sleep(2500);
					System.out.println("Delivery: " + info.get("delivery"));
				}
				else System.out.println("Joke: " + info.get("joke"));
			    }
			
		}catch (Exception e){
			System.out.println(e);
		}
    }
    
}
